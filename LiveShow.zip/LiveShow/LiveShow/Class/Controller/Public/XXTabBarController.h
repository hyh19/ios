#import <UIKit/UIKit.h>

/**
 *  @author 黄玉辉
 *
 *  @brief 自定义TabBarController
 *  @since 0.1.0
 */
@interface XXTabBarController : UITabBarController

@end
