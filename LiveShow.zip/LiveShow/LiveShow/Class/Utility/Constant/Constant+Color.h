#ifndef Constant_Color_h
#define Constant_Color_h

/** 主颜色 */
#define COLOR_MAIN [UIColor hx_colorWithHexString:@"7fddc9"]

/** Tab bar背景颜色 */
#define COLOR_TAB_BAR [UIColor hx_colorWithHexString:@"296758"]

#endif
