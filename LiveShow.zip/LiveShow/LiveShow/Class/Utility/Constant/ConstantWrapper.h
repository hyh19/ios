#ifndef ConstantWrapper_h
#define ConstantWrapper_h

#import "Constant+Device.h"
#import "Constant+Color.h"

#endif
