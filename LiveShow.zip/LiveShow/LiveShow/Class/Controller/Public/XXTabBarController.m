#import "XXTabBarController.h"
#import "JMWhenTapped.h"

@interface XXTabBarController () <UITabBarControllerDelegate>

@end

@implementation XXTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.delegate = self;
    
    UIViewController *viewController1 = [[UIViewController alloc] init];
    UINavigationController *navigationController1 = [[UINavigationController alloc] initWithRootViewController:viewController1];
    UITabBarItem *item1 = [[UITabBarItem alloc] initWithTitle:nil image:[UIImage imageNamed:@"btn_tab_square_normal"] selectedImage:[UIImage imageNamed:@"btn_tab_square_higtlighted"]];
    navigationController1.tabBarItem = item1;
    
    [viewController1.view whenTapped:^{
        UIViewController *nextViewController = [[UIViewController alloc] init];
        nextViewController.hidesBottomBarWhenPushed = YES;
        nextViewController.view.backgroundColor = [UIColor yellowColor];
        [viewController1.navigationController pushViewController:nextViewController animated:YES];
    }];
    
    UIViewController *viewController2 = [[UIViewController alloc] init];
    UINavigationController *navigationController2 = [[UINavigationController alloc] initWithRootViewController:viewController2];
    UITabBarItem *item2 = [[UITabBarItem alloc] initWithTitle:nil image:[UIImage imageNamed:@"btn_tab_me_normal"] selectedImage:[UIImage imageNamed:@"btn_tab_me_highlighted"]];
    navigationController2.tabBarItem = item2;
    
    [viewController2.view whenTapped:^{
        UIViewController *nextViewController = [[UIViewController alloc] init];
        nextViewController.hidesBottomBarWhenPushed = YES;
        nextViewController.view.backgroundColor = [UIColor greenColor];
        [viewController2.navigationController pushViewController:nextViewController animated:YES];
    }];
    
    UIViewController *raisedCenterViewController = [[UIViewController alloc] init];
    
    self.viewControllers = @[navigationController1, raisedCenterViewController, navigationController2];
    
    [self.tabBar setBackgroundImage:[[UIImage alloc] init]];
    [self.tabBar setShadowImage:[[UIImage alloc] init]];
    self.tabBar.backgroundColor = COLOR_TAB_BAR;
    self.tabBar.tintColor = COLOR_MAIN;
    
    CGFloat raisedCenterWidth = 66;
    
    UIButton *raisedCenterButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [raisedCenterButton setImage:[UIImage imageNamed:@"btn_tab_room_normal"] forState:UIControlStateNormal];
    [raisedCenterButton setImage:[UIImage imageNamed:@"btn_tab_room_highligted"] forState:UIControlStateHighlighted];
    raisedCenterButton.frame = CGRectMake((SCREEN_WIDTH-raisedCenterWidth)/2, -(raisedCenterWidth-TAB_BAR_HEIGHT), raisedCenterWidth, raisedCenterWidth);
    raisedCenterButton.layer.cornerRadius = raisedCenterWidth/2;
    [self.tabBar addSubview:raisedCenterButton];
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController {
    if ([viewController isKindOfClass:[UINavigationController class]]) {
        return YES;
    }
    return NO;
}

@end
